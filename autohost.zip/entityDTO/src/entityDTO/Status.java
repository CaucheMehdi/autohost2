package entityDTO;

public class Status {

    public static final String PENDING = "pending";
    public static final String FAILURE = "failure";
}
