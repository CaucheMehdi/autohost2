package com.autohost.managerApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Orderer2Application {

	public static void main(String[] args) {
		SpringApplication.run(Orderer2Application.class, args);
	}

}
